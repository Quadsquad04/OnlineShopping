export class Wishlist{
    public wishlistid : number;
}