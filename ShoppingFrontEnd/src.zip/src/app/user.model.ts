export class User{
    public userid : number;
    public username : string;
    public password : string;
    public email : string;
    public mobile : string;
}