export class Product{
    public productid:number;
    public name : string;
    public imageid : string;
    public brand : string;
    public price : string;
    public quantity : number;
    public categoryid : number;
    public rid : number;

}