export class Category{
    public categoryid:number;
    public categoryname : string;
}