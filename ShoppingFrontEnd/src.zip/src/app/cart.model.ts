export class Cart{
    public cartid : number;
    public quantity : number;
}