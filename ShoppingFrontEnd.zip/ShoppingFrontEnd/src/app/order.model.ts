import { Product } from './product.model';

export class Order{
    public id : number;
    public productid : Product;

}