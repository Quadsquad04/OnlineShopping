export class Retailer{
    public retailerid : number;
    public retailername : string;
    public password : string;
    public email : string;
    public mobile : string;
}