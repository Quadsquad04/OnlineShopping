export class LoginRetailer{
    public email : string;
    public password : string;
}